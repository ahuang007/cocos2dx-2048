local M = require"settings_template"
M.account_conf.account_ip = "47.106.34.35"

return M
