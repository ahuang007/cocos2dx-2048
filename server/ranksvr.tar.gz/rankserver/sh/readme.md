
## 启动脚本

* sh目录包含 

1. 一键启动脚本
- server_dependency.sh
- start.sh 
- stop.sh  
- restart.sh

2. 单个启动脚本
- rank.sh

