./skynet/skynet ./sh/config.rank
