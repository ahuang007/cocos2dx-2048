
local config = {
    [1] = {
        appid   = 1,
        appkey  = 'test001',
        appname = "2048"
    },
    [2] = {
        appid   = 2,
        appkey  = 'test002',
        appname = "flappy bird",
    },
}

return config