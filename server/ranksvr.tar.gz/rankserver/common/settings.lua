local M = require"settings_template"

M.gate_host = "47.106.34.35"
M.rank_conf.login_ip = "47.106.34.35"

return M
